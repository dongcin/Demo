"""
Created on  2018/3/8 14:32

@author: Shu
@author:xtgu
Changed on 2018/3/22
"""

from ac_model.config import parameters
def estimate_risk_value():
	
	V = float(sum(parameters['V'])) / len(str(parameters['V']))
	a = 6 * parameters['eta'] * V * (parameters['rho'] ** (parameters['phi'] + 1))
	b = (parameters['volatility_param'] ** 2) * (parameters['q'] ** 2)
	risk_value = a / b
	return risk_value
