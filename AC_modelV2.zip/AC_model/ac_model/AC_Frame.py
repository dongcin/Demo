# -*- coding: utf-8 -*-
"""
Created on  2018/3/7 09:32

@author: Shu
@xtgu： change in 2018/3/20
"""

import logging
import os
from sympy import *
import pandas as pd
from ac_model.config import parameters

from ac_model import func
from ac_model.estimate_risk_aversion import *
from risk_control import risk_control

orderbook_filepath = os.path.join(os.path.abspath('.'), 'data')


# '/home/ztsdm/SLZ2/extract_book/'
#


def pre_market_vol():
    logging.info("stock is {}".format(parameters['stkcode']))
    mod = func.model_predict(parameters['trade_date'], parameters['stkcode'], orderbook_filepath, scale=False)
    mod.svd()  # predicting trade volume
    predict_V = list(mod.predicted)  # the predicted values
    return predict_V


def epoch_calculate():
    start_time = parameters['start_time'].replace(":", "") + "000"
    end_time = parameters['end_time'].replace(":", "") + "000"
    start_time = int(start_time[1:]) if start_time[0] == '0' else int(start_time)
    end_time = int(end_time[1:]) if end_time[0] == '0' else int(end_time)
    t2 = []
    if start_time <= 112500000 and end_time <= 112500000:
        t1 = list(pd.date_range(start=parameters['start_time'], end=parameters['end_time'],
                                freq=parameters['interval_time']))[:-1]
    elif start_time >= 130000000 and end_time <= 150000000:
        t1 = list(pd.date_range(start=parameters['start_time'], end=parameters['end_time'],
                                freq=parameters['interval_time']))[:-1]
    else:
        t1 = list(pd.date_range(start=parameters['start_time'], end='11:25:00', freq=parameters['interval_time']))
        t2 = list(pd.date_range(start='13:00:00', end=parameters['end_time'], freq=parameters['interval_time']))[:-1]
    t_len = len(t1 + t2)
    parameters['N'] = t_len
    return t1, t2


def function_diff_Hx(p, psi, eta, phi):
    index = int(1 / phi)
    try:
        if (abs(p) - psi) <= 0:
            return 0
        elif p < psi:

            return (((p + psi) / ((phi + 1) * eta)) ** index)
        else:
            return (((p - psi) / ((phi + 1) * eta)) ** index)
    except:
        ## sell
        if parameters['BSflag'] == 'S':
            return ((p + psi) / ((phi + 1) * eta)) ** index
        ## buy
        else:
            return ((p - psi) / ((phi + 1) * eta)) ** index


def hamiltonian_system(p):
    C_q = []
    C_q.append(parameters['q'])
    C_p = []
    C_p.append(p)
    q = parameters['q']
    Q_T = sum(parameters['V'])
    for n in range(parameters['N'] - 1):
        temp_p = p
        Q_n = sum(parameters['V'][:(n + 1)])
        q = q + parameters['Delta_t'] * parameters['V'][n + 1] * function_diff_Hx(temp_p, parameters['psi'],
                                                                                  parameters['eta'], parameters['phi'])
        C_q.append(q)
        # VWAP in AC_FrameWork
        p = temp_p + parameters['Delta_t'] * (parameters['risk_aversion_param'] * parameters['volatility_param'] ** 2
                                              * (q - parameters['q'] * (1 - (Q_n / Q_T))) + (
                                              (parameters['k'] * parameters['q'] * parameters['V'][n + 1]) / Q_T))
        C_p.append(p)
    return (p, q, C_q)


def AC_frame():
    p = Symbol('x')
    _, q, _ = hamiltonian_system(p)
    p = solve(q)[0]
    p, q, C_q = hamiltonian_system(p)
    t1, t2 = epoch_calculate()
    w1 = [int((x.hour) * 1e7 + (x.minute) * 1e5) for x in t1]
    if len(t2) != 0:
        w2 = [int((x.hour) * 1e7 + (x.minute) * 1e5) for x in t2]

    if parameters['BSflag'] == 'B':
        # print("buy")
        if len(t2) > 0:
            trade_vol_list_1 = [(parameters['stkcode'], parameters['trade_date'], w1[i], parameters['lasttime'],
                                 -int(int(C_q[i] - C_q[i + 1]) / 100) * 100) for i in range(len(w1) - 1)]
            trade_vol_list_2 = [(parameters['stkcode'], parameters['trade_date'], w2[i], parameters['lasttime'],
                                 -int(int(C_q[len(t1) + i] - C_q[len(t1) + i + 1]) / 100) * 100) for i in
                                range(len(w2) - 2)]
            if C_q[-1] > 1000:
                trade_vol_list_2.append((parameters['stkcode'], parameters['trade_date'], w2[-2],
                                         parameters['lasttime'], -int(int(C_q[-1]) / 100) * 100))
            trade_vol_list = trade_vol_list_1 + trade_vol_list_2
        else:
            trade_vol_list_1 = [(parameters['stkcode'], parameters['trade_date'], w1[i], parameters['lasttime'],
                                 -int(int(C_q[i] - C_q[i + 1]) / 100) * 100) for i in range(len(w1) - 1)]
            if C_q[-1] > 1000:
                trade_vol_list_1.append((parameters['stkcode'], parameters['trade_date'], w1[-2],
                                         parameters['lasttime'], -int(int(C_q[-1]) / 100) * 100))
            trade_vol_list = trade_vol_list_1
    else:
        # print("sell")
        if len(t2) > 0:
            trade_vol_list_1 = [(parameters['stkcode'], parameters['trade_date'], w1[i], parameters['lasttime'],
                                 int(int(C_q[i] - C_q[i + 1]) / 100) * 100) for i in range(len(w1) - 1)]
            trade_vol_list_2 = [(parameters['stkcode'], parameters['trade_date'], w2[i], parameters['lasttime'],
                                 int(int(C_q[len(t1) + i] - C_q[len(t1) + i + 1]) / 100) * 100) for i in
                                range(len(w2) - 2)]
            if C_q[-1] > 1000:
                trade_vol_list_2.append((parameters['stkcode'], parameters['trade_date'], w2[-2],
                                         parameters['lasttime'], -int(int(C_q[-1]) / 100) * 100))
            trade_vol_list = trade_vol_list_1 + trade_vol_list_2
        else:
            trade_vol_list_1 = [(parameters['stkcode'], parameters['trade_date'], w1[i], parameters['lasttime'],
                                 int(int(C_q[i] - C_q[i + 1]) / 100) * 100) for i in range(len(w1) - 1)]
            if C_q[-1] > 1000:
                trade_vol_list_1.append((parameters['stkcode'], parameters['trade_date'], w1[-2],
                                         parameters['lasttime'], -int(int(C_q[-1]) / 100) * 100))
            trade_vol_list = trade_vol_list_1

    return C_q, trade_vol_list


def _test():
    # 计算时间片
    epoch_calculate()

    parameters['V'] = pre_market_vol()
    parameters['risk_aversion_param'] = estimate_risk_value()

    C_q, volume_piece_list = AC_frame()
    ## 提取下单队列
    volume_piece = [x[4] for x in volume_piece_list]
    current_time = 133001000
    epoch = 0
    # 一开始的量
    start_volume = parameters['q']
    traded_volume = 0
    traded_money = 0
    per_lmt = 0.3
    # 测试
    #rc = risk_control()
    while current_time < 1500 * 100000:

        '''限价单'''
        # 当前市场最有价##
        price = 32.2
        if epoch >= parameters['N'] - 1:
            remained_volumn = start_volume - traded_volume
            vol_trade_piece = remained_volumn
        else:
            vol_trade_piece = volume_piece[epoch]

        # vol_trade_piece下单量
        traded_volume += vol_trade_piece * per_lmt
        traded_money += price * vol_trade_piece * per_lmt
        ''' 市价单 '''

        price = 31.2
        if epoch >= parameters['N'] - 1:
            vol_trade_piece = remained_volumn
        else:
            vol_trade_piece = volume_piece[epoch]
        traded_volume += vol_trade_piece * (1 - per_lmt)
        traded_money += price * vol_trade_piece * (1 - per_lmt)
        print("volume:", vol_trade_piece, "| market_price:", price, "| time:", current_time)
        current_time += 500000
        if current_time % (100 * 100000) >= 60 * 100000:
            current_time += 40 * 100000
        if 1130 * 100000 <= current_time < 1300 * 100000:
            current_time = 1300 * 100000
        epoch += 1
    print(traded_volume)

    exit(0)


if __name__ == '__main__':
    _test()
