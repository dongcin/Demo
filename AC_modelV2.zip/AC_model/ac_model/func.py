import pandas as pd
import numpy as np
import os
import datetime
import sys
import time
import math
from sklearn.decomposition import TruncatedSVD
from sklearn.decomposition import NMF
from sklearn.decomposition import SparsePCA
from sklearn.linear_model import LinearRegression
import statsmodels.api as sm


def get_data(input_dir,file,stock_code):
    trade_data = pd.DataFrame()
    input_path = os.path.join(input_dir, file)
    trade_df = pd.read_hdf(input_path, 'trade')
    trade_df['TradeType'] = trade_df['TradeType'].str.strip()
    trade_df = trade_df[trade_df['SecurityID'] == int(stock_code)]
    trade_df['TradeCode'] = trade_df['TradeCode'].str.strip()
    trade_data = pd.concat([trade_data, trade_df], axis=0)
    trade_data = trade_data.sort_values(['Date', 'TradeTime'])
    trade_data = trade_data.reset_index(drop=True)
    return trade_data


def filter_time(dataframe, date):
    df = dataframe
    start = '{} 9:30:00'.format(date)
    end = '{} 15:00:00'.format(date)
    idx = pd.date_range(start, end, freq='1T')
    idx = np.array([int(str(i)[11:16].replace(":", "", 1)) for i in idx])
    idx = idx[((idx > 929) * (idx < 1130)) + ((idx >= 1300) * (idx < 1500))]
    df = df.reindex(idx)
    df = df.fillna(0)
    return df


def preprocess(trade_data, time_span=5):
    trade_data = trade_data.ix[(np.array(trade_data["TradeCode"] == "F") * np.array(trade_data["TradeTime"] > 93000000)), ["Date", "TradeQTY", "TradeTime"]]
    trade_data["TradeTime"] = [int(str(i)[:-5]) for i in trade_data["TradeTime"]]
    date = trade_data["Date"].iloc[0]
    vol = trade_data.groupby(trade_data["TradeTime"])["TradeQTY"].sum()
    vol = filter_time(vol, trade_data["Date"].iloc[0])
    vol = [sum(vol.iloc[range(i, i + time_span)]) for i in range(0, 240, time_span)]
    return pd.DataFrame({date: vol})


class model_predict():
    def __init__(self, date, stock_code, input_dir, time_span=5, trailing_days=20, scale=False):
        self.date = date
        self.stock_code = stock_code
        self.input_dir = os.path.join(input_dir, stock_code)
        self.time_span = time_span
        self.trailing_days = trailing_days
        self.scale = scale
        self.train = pd.DataFrame()
        file_list = np.array(os.listdir(self.input_dir))
        file_list.sort()
        file_list = file_list[file_list < 'SZL2_{}_{}.h5'.format(self.stock_code, self.date)][-self.trailing_days:]
        if len(file_list)<self.trailing_days:
            print("Sample is not enough")
        for file in file_list:
            trade_data_tmp = get_data(self.input_dir, file, stock_code)
            if isinstance(trade_data_tmp, pd.DataFrame):
                vol = preprocess(trade_data_tmp)
                self.train = pd.concat([self.train, vol], axis=1)
            # print("Reading {}".format(file))
        if self.scale:
            n, p = self.train.shape
            weights = np.array([i for i in range(1, p + 1, 1)])
            weights = weights / sum(weights)
            self.vol_train = self.train.apply(sum)
            self.total_vol_predicted = np.dot(np.array(self.vol_train).reshape(1, p), np.array(weights).reshape(p, 1))
            self.train = np.dot(self.train, np.diag(1 / self.vol_train))
			
    def naive(self):
        self.predicted = np.array(self.train).mean(axis=1)
		
    def svd(self):
        svd_func = TruncatedSVD(algorithm='randomized', n_components=2, n_iter=7)
        svd_func.fit(self.train)
        self.predicted = np.dot(svd_func.transform(self.train), svd_func.components_).mean(axis=1)
		
    def wm(self):
        n, p = self.train.shape
        weights = np.array([i for i in range(1, p + 1, 1)])
        weights = weights / sum(weights)
        self.predicted = np.dot(self.train, weights)
		
    def nmf(self):
        nmf_func = NMF(n_components=2, init='random', random_state=0)
        W = nmf_func.fit_transform(self.train)
        H = nmf_func.components_
        self.predicted = np.array(np.dot(W, H)).mean(axis=1)
		
    def rsvd(self):
        rsvd_func = SparsePCA(n_components=2, ridge_alpha=0.01, alpha=0.01)
        rsvd_func.fit(self.train)
        rsvd_fitted = np.dot(rsvd_func.transform(self.train), rsvd_func.components_)
        self.predict = self.svd(rsvd_fitted).mean(axis=1)
        self.predict = self.predict / sum(self.predict)

# #### example: ####
#
# mod = model_predict(date = '20171129',stock_code = '000002',input_dir = '/home/ztsdm/SLZ2/extract_book/')
# mod.svd() # predicting trade volume
# predict = mod.predicted #the predicted values