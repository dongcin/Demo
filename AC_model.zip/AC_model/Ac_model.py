### TWAP
###time_interval:5min
import pandas as pd
from ac_model.config import args
from ac_model.AC_Frame import *

M_TICKER = args.stkcode
M_EXCHANGE = EXCHANGE.SZE
SOURCE_INDEX = SOURCE.XTP





def text_save(content, filename, mode='a'):
    file = open(filename, mode)
    file.write(content)
    file.close()


def check(context):
    if context.trade_volume < context.cur_volume:
        context.cancel_rid = context.cancel_order(source=SOURCE_INDEX, order_id=context.limit_rid)
        print("canceling order: %s" % context.cancel_rid)
        context.market_rid = context.insert_market_order(source=SOURCE_INDEX,
                                                         ticker=M_TICKER,
                                                         exchange_id=M_EXCHANGE,
                                                         volume=(context.cur_volume - context.trade_volume),
                                                         direction=DIRECTION.Buy,
                                                         offset=OFFSET.Open)
        print("puting market order : %s" % context.market_rid)
        context.epoch+=1
        context.trade_volume_amt+=context.cur_volume


def initialize(context):
    print('--- running ', context.get_name(), '---')
    context.add_md(source=SOURCE_INDEX)
    context.add_td(source=SOURCE_INDEX)
    context.subscribe(tickers=[M_TICKER], source=SOURCE_INDEX)
    context.register_bar(source=SOURCE_INDEX, min_interval=1, start_time='09:30:00', end_time='15:00:00')
    context.prev_t = context.parse_nano(context.get_nano())
    # 计算时间片
    epoch_calculate(args)
    #交易时间点
    year=args.trade_date[:4]
    mon=args.trade_date[5] if args.trade_date[4]=='0' else args.trade_date[4:6]
    day=args.trade_date[7] if args.trade_date[6]=='0' else args.trade_date[6:8]
    start_time=mon+'/'+day+'/'+year+' '+args.start_time
    end_time=mon+'/'+day+'/'+year+' '+args.end_time
    context.tseries = pd.date_range(start_time, end_time, freq=args.interval_time).map(
        lambda x: str(x)).values
    context.tseries = context.tseries[context.tseries > context.prev_t]
    context.next_t = context.tseries[0]
    context.tick_price = []
    context.bar_price = []
    # 初始化算法
    args.risk_aversion_param = estimate_risk_value(args)
    C_q, volume_piece_list = AC_frame(args)
    ## 提取下单队列
    context.volume_piece = [x[4] for x in volume_piece_list]
    context.epoch=0
    context.start_volume=args.q
    context.trade_volume_amt=0
    print('initialization done')


def on_pos(context, pos_handler, request_id, source, rcv_time):
    if request_id == -1:
        context.log_info("td connection")
        if pos_handler is None:
            context.log_info("initializing pos_handler")
            context.set_pos(context.new_pos(source=source), source=source)
    else:
        context.log_debug("[RSP_POS] {}".format(pos_handler.dump()))


def on_tick(context, market_data, source, rcv_time):
    context.tick_price.append([rcv_time, market_data.BidPrice1, market_data.AskPrice1])
    #'tick_price: ',context.tick_price[-1],'current_time:', rcv_time, 'bid:', market_data.BidPrice1, 'ask:', market_data.AskPrice1
    if context.parse_nano(rcv_time) > context.next_t:
        curr_t = context.parse_nano(rcv_time)
        price=market_data.BidPrice1 if args.BSflag=='B' else market_data.AskPrice1
        if context.epoch >= args.N-1:
            remained_volumn = context.start_volume - context.traded_volume_amt
            vol_trade_piece = remained_volumn
        else:
            vol_trade_piece = context.volume_piece[context.epoch]
        context.cur_volume=vol_trade_piece

        print("##ORDER:",'current_time:', curr_t, 'rcv_time', rcv_time, 'price:',price, 'volume:', vol_trade_piece)

        context.limit_rid = context.insert_limit_order(source=SOURCE_INDEX,
                                                       ticker=M_TICKER,
                                                       exchange_id=M_EXCHANGE,
                                                       price=price,
                                                       volume=vol_trade_piece,
                                                       direction=DIRECTION.Buy,
                                                       offset=OFFSET.Open)
        context.trade_volume = 0
        context.next_t = context.tseries[context.tseries > curr_t][0]

        context.insert_func_after_c(args.lasttime, check)


def on_bar(context, bars, min_interval, source, rcv_time):
    for ticker, bar in bars.items():
        print(ticker, 'o', bar.Open, 'h', bar.High, 'l', bar.Low, 'c', bar.Close, 'vol', bar.Volume)
        context.bar_price.append([rcv_time, bar.Open, bar.Close, bar.Volume])
        print('bar_price: ', context.bar_price[-1])
        text_save(str(context.bar_price[-1][0]) + ',' + str(context.bar_price[-1][1]) + ',' + str(
            context.bar_price[-1][2]) + ',' + str(context.bar_price[-1][3]) + '\n', r'bar_price.txt')


def on_rtn_trade(context, rtn_trade, order_id, source, rcv_time):
    context.log_debug("[TRADE] (t){} (p){} (v){} POS:{}".format(
        rtn_trade.InstrumentID, rtn_trade.Price, rtn_trade.Volume,
        context.get_pos(source=SOURCE_INDEX).dump()))
    if context.limit_rid == order_id:
        context.trade_volume += rtn_trade.Volume
        print('buying %s shares by limit order' % rtn_trade.Volume)
    else:
        print('market order success, buying price:%s' % rtn_trade.Price)
