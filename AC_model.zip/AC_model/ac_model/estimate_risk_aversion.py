"""
Created on  2018/3/8 14:32

@author: Shu
"""


def estimate_risk_value(args):
	
	V = float(sum(args.V)) / len(str(args.V))
	a = 6 * args.eta * V * (args.rho ** (args.phi + 1))
	b = (args.volatility_param ** 2) * (args.q ** 2)
	risk_value = a / b
	return risk_value
