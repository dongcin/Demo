import pandas as pd
import os
import pdb
from config import logging

def marketvol_load(trade_date, stkcode = '000002'):
	
	filename_true_market_vol = 'VOL_'+stkcode+'.csv'
	filename_pre_market_vol = 'VOL_pre_'+stkcode+'.csv'
	filename_true_market_dist = 'VOL_distrib_'+stkcode+'.csv'
	filename_pre_market_dist = 'VOL_distrib_pre_'+stkcode+'.csv'
	
	true_market_vol = pd.read_csv(filename_true_market_vol, header = 0, index_col = 0)
	pre_market_vol = pd.read_csv(filename_pre_market_vol, header=0, index_col=0)
	true_market_dist = pd.read_csv(filename_true_market_dist, header=0, index_col=0)
	pre_market_dist = pd.read_csv(filename_pre_market_dist, header=0, index_col=0)
	
	true_market_vol_list = list(true_market_vol[trade_date])
	pre_market_vol_list = list(pre_market_vol[trade_date])
	true_market_dist_list = list(true_market_dist[trade_date])
	pre_market_dist_list = list(pre_market_dist[trade_date])
	
	return true_market_vol_list, pre_market_vol_list, true_market_dist_list, pre_market_dist_list


def marketvol_loadh5(trade_date, stkcode = '000002'):
	
	filename = '/home/ztsdm/SLZ2/extract_book/' + stkcode + '/SZL2_' + stkcode + '_' + trade_date + '.h5'
	
	trade_df = pd.read_hdf(filename, 'trade')
	
	
	
	t1 = list(pd.date_range(start='09:30', periods=25, freq='5min'))
	t2 = list(pd.date_range(start='13:00', periods=25, freq='5min'))
	T = t1 + t2
	w1 = [int((x.hour) * 1e7 + (x.minute) * 1e5) for x in t1]
	w2 = [int((x.hour) * 1e7 + (x.minute) * 1e5) for x in t2]

	trade_diff_list_1 = [trade_df[(trade_df["RecvTime"]>= w1[i]) & (trade_df["RecvTime"]< w1[i+1]) & (trade_df["TradeCode"] != 'C')]["TradeQTY"].sum() for i in range(len(w1)-1)]
	
	trade_diff_list_2 = [trade_df[(trade_df["RecvTime"] >= w2[i]) & (trade_df["RecvTime"] < w2[i + 1]) & (trade_df["TradeCode"] != 'C')]["TradeQTY"].sum() for i in range(len(w2) - 1)]
	
	trade_diff_list = trade_diff_list_1 + trade_diff_list_2
	loggging.info("trade_diff_list is {}, length is {}".format(trade_diff_list, len(trade_diff_list)))
	return trade_diff_list