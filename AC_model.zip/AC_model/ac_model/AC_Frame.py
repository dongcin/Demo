# -*- coding: utf-8 -*-
"""
Created on  2018/3/7 09:32

@author: Shu
@xtgu： change in 2018/3/20
"""

from sympy import *
import os
from ac_model.estimate_risk_aversion import *
from ac_model.market_vol_files.marketvol_load import *
from ac_model.market_vol_files import func
from ac_model.config import args
import logging

orderbook_filepath =os.path.join(os.path.abspath('.'),'data')
    #'/home/ztsdm/SLZ2/extract_book/'
    #


def pre_market_vol(args):
    logging.info("stock is {}".format(args.stkcode))
    mod = func.model_predict(args.trade_date, args.stkcode, orderbook_filepath, scale=False)
    mod.svd()  # predicting trade volume
    predict_V = list(mod.predicted)  # the predicted values
    return predict_V

def epoch_calculate(args):

    start_time = args.start_time.replace(":", "") + "000"
    end_time = args.end_time.replace(":", "") + "000"
    start_time = int(start_time[1:]) if start_time[0] == '0' else int(start_time)
    end_time = int(end_time[1:]) if end_time[0] == '0' else int(end_time)
    t2=[]
    if start_time <= 112500000 and end_time <= 112500000:
        t1=list(pd.date_range(start=args.start_time, end=args.end_time, freq=args.interval_time))[:-1]
    elif  start_time >= 130000000 and end_time <= 150000000:
        t1=list(pd.date_range(start=args.start_time,end=args.end_time, freq=args.interval_time))[:-1]
    else:
        t1 = list(pd.date_range(start=args.start_time, end='11:25:00', freq=args.interval_time))
        t2 = list(pd.date_range(start='13:00:00', end=args.end_time, freq=args.interval_time))[:-1]
    t_len=len(t1+t2)
    args.N = t_len
    return t1,t2


def function_diff_Hx(p, psi, eta, phi):
    index = int(1 / phi)
    try:
        if (abs(p) - psi) <= 0:
            return 0
        elif p < psi:

            return (((p + psi) / ((phi + 1) * eta)) ** index)
        else:
            return (((p - psi) / ((phi + 1) * eta)) ** index)
    except:
        ## sell
        if args.BSflag == 'S':
            return ((p + psi) / ((phi + 1) * eta)) ** index
        ## buy
        else:
            return ((p - psi) / ((phi + 1) * eta)) ** index

def hamiltonian_system( args, p):
    C_q = []
    C_q.append(args.q)
    C_p = []
    C_p.append(p)
    q = args.q
    Q_T = sum(args.V)
    for n in range(args.N - 1):
        temp_p = p
        Q_n = sum(args.V[:(n + 1)])
        q = q + args.Delta_t * args.V[n + 1] * function_diff_Hx(temp_p, args.psi, args.eta, args.phi)
        C_q.append(q)
        # VWAP in AC_FrameWork
        p = temp_p + args.Delta_t * (args.risk_aversion_param * args.volatility_param ** 2
                                     * (q - args.q * (1 - (Q_n / Q_T))) + ((args.k * args.q * args.V[n + 1]) / Q_T))
        C_p.append(p)
    return (p, q, C_q)

def AC_frame( args):
    p = Symbol('x')
    _, q, _ = hamiltonian_system(args, p)
    p = solve(q)[0]
    p, q, C_q = hamiltonian_system(args, p)
    t1,t2=epoch_calculate(args)
    w1 = [int((x.hour) * 1e7 + (x.minute) * 1e5) for x in t1]
    if len(t2) != 0:
        w2 = [int((x.hour) * 1e7 + (x.minute) * 1e5) for x in t2]

    if args.BSflag == 'B':
        #print("buy")
        if len(t2)>0:
            trade_vol_list_1 = [(args.stkcode, args.trade_date, w1[i], args.lasttime,
                             -int(int(C_q[i] - C_q[i + 1]) / 100) * 100) for i in range(len(w1) - 1)]
            trade_vol_list_2 = [(args.stkcode, args.trade_date, w2[i], args.lasttime,
                             -int(int(C_q[len(t1) + i] - C_q[len(t1) + i + 1]) / 100) * 100) for i in range(len(w2) - 2)]
            if C_q[-1] > 1000:
                trade_vol_list_2.append((args.stkcode, args.trade_date, w2[-2],
                                     args.lasttime, -int(int(C_q[-1]) / 100) * 100))
            trade_vol_list = trade_vol_list_1 + trade_vol_list_2
        else:
            trade_vol_list_1 = [(args.stkcode, args.trade_date, w1[i], args.lasttime,
                                 -int(int(C_q[i] - C_q[i + 1]) / 100) * 100) for i in range(len(w1) - 1)]
            if C_q[-1] > 1000:
                trade_vol_list_1.append((args.stkcode, args.trade_date, w1[-2],
                                     args.lasttime, -int(int(C_q[-1]) / 100) * 100))
            trade_vol_list = trade_vol_list_1
    else:
        #print("sell")
        if len(t2)>0:
            trade_vol_list_1 = [(args.stkcode, args.trade_date, w1[i], args.lasttime,
                             int(int(C_q[i] - C_q[i + 1]) / 100) * 100) for i in range(len(w1) - 1)]
            trade_vol_list_2 = [(args.stkcode, args.trade_date, w2[i], args.lasttime,
                             int(int(C_q[len(t1) + i] - C_q[len(t1) + i + 1]) / 100) * 100) for i in range(len(w2) - 2)]
            if C_q[-1] > 1000:
                trade_vol_list_2.append((args.stkcode, args.trade_date, w2[-2],
                                     args.lasttime, -int(int(C_q[-1]) / 100) * 100))
            trade_vol_list = trade_vol_list_1 + trade_vol_list_2
        else:
            trade_vol_list_1 = [(args.stkcode, args.trade_date, w1[i], args.lasttime,
                                 int(int(C_q[i] - C_q[i + 1]) / 100) * 100) for i in range(len(w1) - 1)]
            if C_q[-1] > 1000:
                trade_vol_list_1.append((args.stkcode, args.trade_date, w1[-2],
                                     args.lasttime, -int(int(C_q[-1]) / 100) * 100))
            trade_vol_list = trade_vol_list_1

    return C_q, trade_vol_list


def _test():
    #计算时间片
    epoch_calculate(args)

    args.V = pre_market_vol(args)
    args.risk_aversion_param = estimate_risk_value(args)

    C_q, volume_piece_list = AC_frame(args)
    ## 提取下单队列
    volume_piece = [x[4] for x in volume_piece_list]
    current_time = 133001000
    epoch = 0
    #一开始的量
    args.q=10000
    start_volume=args.q
    traded_volume=0
    traded_money=0
    per_lmt=0.3
    while current_time < 1500 * 100000:

        '''限价单'''
        #当前市场最有价##
        price=32.2
        if epoch >= args.N-1:
            remained_volumn = start_volume- traded_volume
            vol_trade_piece = remained_volumn
        else:
            vol_trade_piece = volume_piece[epoch]

        #vol_trade_piece下单量
        traded_volume += vol_trade_piece * per_lmt
        traded_money += price * vol_trade_piece * per_lmt
        ''' 市价单 '''

        price = 31.2
        if epoch >= args.N-1:
            vol_trade_piece = remained_volumn
        else:
            vol_trade_piece = volume_piece[epoch]
        traded_volume += vol_trade_piece * (1 - per_lmt)
        traded_money += price * vol_trade_piece * (1 - per_lmt)
        print("volume:", vol_trade_piece , "| market_price:", price,"| time:",current_time)
        current_time += 500000
        if current_time % (100 * 100000) >= 60 * 100000:
            current_time += 40 * 100000
        if 1130 * 100000 <= current_time < 1300 * 100000:
            current_time = 1300 * 100000
        epoch += 1
    print(traded_volume)

    exit(0)
''''
if __name__ == '__main__' :
    _test()
'''



