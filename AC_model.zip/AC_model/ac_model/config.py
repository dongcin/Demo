import argparse
import logging


logger = logging.getLogger()
logger.setLevel(logging.INFO)


parser = argparse.ArgumentParser()
parser.add_argument("-N", "--N", type=int, default=48, help="number of slices ")
parser.add_argument("-T", "--T", type=int, default=1, help="for one given day ")
parser.add_argument("-R", "--risk_aversion_param", type=int, default=1e-6, help="risk_aversion_param")
parser.add_argument("-Vo", "--volatility_param", type=float, default=0.6, help="volatility_param (sigma σ)")
parser.add_argument("-eta", "--eta", type=float, default=0.1, help="the liquidity parameter (η)")
parser.add_argument("-psi", "--psi", type=float, default=0.004, help="cost coefficient")
parser.add_argument("-phi", "--phi", type=float, default=1, help="increase output verbosity")
parser.add_argument("-q", "--q", type=float, default=500000, help="position at time 0 (shares)")
parser.add_argument("-rho", "--rho", type=float, default=0.25, help="Optimal participation rate (%)")
parser.add_argument("-k", "--k", type=float, default=1e-8, help="pernmant market impact factor")

#下单设置
parser.add_argument("-start_time", "--start_time", type=str, default='10:30:00', help="start_time")
parser.add_argument("-end_time", "--end_time", type=str, default='15:00:00', help="end_time")
parser.add_argument("-trade_date", "--trade_date", type=str, default='20180102', help="trade date")
parser.add_argument("-stkcode", "--stkcode", type=str, default='000002', help="stkcode")
parser.add_argument("-bsflag", "--BSflag", type=str, default='S', help="bsflag")
parser.add_argument("-lasttime", "--lasttime", type=int, default=280, help="after * time change limit order to market order ")
parser.add_argument("-interval_time", "--interval_time", type=str, default='5min', help="interval")


args = parser.parse_args()

Delta_t = round(args.T / args.N, 2)
args.Delta_t = Delta_t
